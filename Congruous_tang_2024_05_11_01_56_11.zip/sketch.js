var  back1;
var  back2;
var shape;
//let mode = 0;
function preload(){
  back1 = loadImage("1-1.jpg")
  back2= loadImage("Beach.jpg")
  
}
function setup() {
  createCanvas(400, 400);
  shape=width/2;
  fill(0)
   text ("Press 1 or 2 to change the background and move the arrow keys to the square", 0, height-40);
}

function draw() {
  push();
  image(back1,0,0,width,height);
    pop();
   /* switch (mode) {
    case 0:
      background(255);
      break;
    case 1:
      scene1();
      break;
    case 2:
      scene2();
      break;
      default:
  }
  
  if (mode == 0) {
    // ready
  }
  else if (mode == 1) {
    scene1();
  }
  else if (mode == 2) {
    scene2();
  
  }*/

  
  //line(0, height-50, width, height-50);
  push();
  fill(255,0,0)
  rect(shape, height-70, 25,25);
  pop();
  if(keyIsPressed){
    if (keyCode == LEFT_ARROW){
      shape--;
    }else if (keyCode == RIGHT_ARROW){
      shape++;
    }
  }
  
function mousePressed() {
  mode++;
}
function scene1() {
 image(back1,0,0,width,height);
}

function scene2() {
 image(back2,0,0,wid1th,height);
}
}